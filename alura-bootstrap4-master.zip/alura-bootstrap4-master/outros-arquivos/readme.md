# Projeto para curso de Bootstrap 4

## Ementa (sujeita a alterações)

* Apresentação da ferramenta
* O que é framework
* Criar html
* Meta charset
* Editor de texto
* Instalação bootstrap (CDN / arquivos locais)
* Estrutura pastas e tipos de arquivo btsp
* Ferramentas de dev
* Inserir img no HTML
* Conceito de mobile first
* Meta viewport
* Imgs responsivas
* Btsp: div container
* Collapse
* Attrs: data-toggle e data-target
* Arrumando padding sem ser pelo css
* Attr: data-parent
* Tags semânticas: figcaption, figure, section
* Components > carousel
* Attrs do carousel
* Fazendo modificações pelo css
* Formulários com btsp
* Classes de formulário
* Tag button + estilos do tsp
* Tags semânticas
* Menus com ul + li e âncoras
* Components > navbar
* Classes de navbar
* Botão menu hamburguinho
* CSS: media query
* Sistema de colunas do btsp
* Estilização 100% (ou perto de 100%) via btsp
* breakpoints de tela
* classes de alinhamento com flexbox via btsp
* classes de padding e margin do btsp
* classes de estilização de texto do btsp
* classes de tamanho dinâmico via btsp (com em e rem)
* Components > cards
* Borders
* Modais
* Shadows
* Attr aria
* Border radius
